#' This data set serves for examples and tests.
#'
#' This is a simulated data set that 100 observation of six normally
#' distributed variables with mean = 0, variance = 1 and covariance 0.5.
#'
#' @format A data frame with 100 rows and 6 variables:
#'
"semnova_test_data"
